import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import * as CanvasJS from './../assets/canvasjs.min.js';
// import { AppService } from './app.service.js';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {

  portfolioForm: FormGroup
  portfolioData: any = [];
  
  constructor(public fb: FormBuilder) {}

  ngOnInit() {
    this.formInit()
    this.chartInit()
    // this.service.getPortfolio().subscribe((res)=>{
    //   if(res) {
    //     this.portfolioData = res;
    //   }
    // })
  }

  chartInit(){
    let chart = CanvasJS.chart('chartContainer',{
      theme:'light',
      title:{
        text: 'Portfolio Performance'
      },
      showInLegend: true,
      data:[{
        type:'pie',
        label:"{indexLabel}",
        datapoints:[
          {y:45, indexLabel:'port1'},
          {y:35, indexLabel:'port2'},
          {y:65, indexLabel:'port4'},
          {y:85, indexLabel:'port5'}
        ]
      }]
    })
    chart.render()
  }

  savePortfolio() {
    console.log(this.portfolioForm.value)
    const obj = {assetType:this.portfolioForm.value.assetType,
      quantity:this.portfolioForm.value.quantity,
      price:this.portfolioForm.value.price,
      date:this.portfolioForm.value.date}
    this.portfolioData.push(obj)
    console.log(this.portfolioData)
    // this.service.savePortfolioData(obj).subscribe((res)=>{

    // })
  }

  formInit() {
    this.portfolioForm = this.fb.group({
      assetType: ['', Validators.required],
      quantity: ['', Validators.required],
      price: ['', Validators.required],
      date: ['', Validators.required]
    })
  }


}
